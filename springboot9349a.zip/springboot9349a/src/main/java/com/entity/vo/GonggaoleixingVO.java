package com.entity.vo;

import com.entity.GonggaoleixingEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
 

/**
 * 公告类型
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2023-05-01 12:14:49
 */
public class GonggaoleixingVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 				
}
